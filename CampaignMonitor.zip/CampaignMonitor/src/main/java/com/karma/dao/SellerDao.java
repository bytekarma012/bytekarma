package com.karma.dao;

import com.karma.model.Seller;

public interface SellerDao {

	public Boolean isValidSeller(String sellerId,String password);
	
	public void createSeller(Seller seller);
	
	public Seller getSellerDetails(String sellerId);
	
}
