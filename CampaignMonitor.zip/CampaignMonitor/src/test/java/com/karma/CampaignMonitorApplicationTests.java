package com.karma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampaignMonitorApplicationTests {

	@Test
	void contextLoads() {
	}

}
