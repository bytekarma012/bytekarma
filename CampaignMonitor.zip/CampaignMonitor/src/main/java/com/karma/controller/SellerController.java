package com.karma.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.karma.model.Seller;
import com.karma.service.SellerService;

@CrossOrigin
@RestController
public class SellerController {

	@Autowired
	SellerService sellerService;
	
	@PostMapping(value = "/seller/{sellerId}")
	public ResponseEntity<String> getSellerCredentials(@PathVariable String sellerId,@RequestBody String password){
		ResponseEntity<String> responseEntity = null;
		try {
			if(sellerService.isValidSeller(sellerId, password))
				responseEntity = new ResponseEntity<String>("Seller logged in successfully",HttpStatus.OK);
			else
				responseEntity = new ResponseEntity<>("Invalid Credentials",HttpStatus.NOT_FOUND);
		}catch (Exception e) {
			// TODO: handle exception
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}
	
	@PostMapping(value = "/seller")
	public ResponseEntity<String> addSeller(@RequestBody Seller seller){
		ResponseEntity<String> responseEntity = null;
		try {
			sellerService.createSeller(seller);
			responseEntity = new ResponseEntity<String>("Seller Successfully Added",HttpStatus.OK);
		}catch (Exception e) {
			// TODO: handle exception
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}
	
	@GetMapping(value = "/seller/{sellerId}")
	public ResponseEntity<Seller> getSellerDetails(@PathVariable String sellerId){
		ResponseEntity<Seller> responseEntity = null;
		try {
			
				responseEntity = new ResponseEntity<Seller>(sellerService.getSellerDetails(sellerId),HttpStatus.OK);
		}catch (Exception e) {
			// TODO: handle exception
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}
	
}
