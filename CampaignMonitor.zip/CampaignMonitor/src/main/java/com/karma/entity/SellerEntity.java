package com.karma.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "seller")
public class SellerEntity {

	@Column(name="name")
	@NotNull
	private String name;
	
	@Id
	@Column(name="seller_id")
	private String sellerId;
	
	@Column(name="password")
	@NotNull
	private String password;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "SellerEntity [name=" + name + ", sellerId=" + sellerId + ", password=" + password + "]";
	}
	
	
	
}
