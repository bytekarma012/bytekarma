package com.karma.model;

import java.util.List;

public class Recepients {

	private List<String> emailTo;

	public List<String> getEmailTo() {
		return emailTo;
	}

	public void setEmailTo(List<String> emailTo) {
		this.emailTo = emailTo;
	}
	
	
}
