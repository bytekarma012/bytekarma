package com.karma.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.karma.dao.SellerDao;
import com.karma.model.Seller;

@Transactional
@Service(value = "sellerService")
public class SellerServiceImpl implements SellerService {

	@Autowired
	private SellerDao sellerDao;
	
	@Override
	public Boolean isValidSeller(String sellerId, String password) {
		// TODO Auto-generated method stub
		return sellerDao.isValidSeller(sellerId, password);
		
	}

	@Override
	public void createSeller(Seller seller) {
		// TODO Auto-generated method stub
		sellerDao.createSeller(seller);
	}

	@Override
	public Seller getSellerDetails(String sellerId) {
		// TODO Auto-generated method stub
		return sellerDao.getSellerDetails(sellerId);
	}

}
