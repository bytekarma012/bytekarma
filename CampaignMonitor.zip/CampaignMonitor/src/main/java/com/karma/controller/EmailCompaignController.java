package com.karma.controller;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import com.karma.model.Email;
import com.karma.model.EmailCampaign;
import com.karma.model.Recepients;
import com.karma.model.Sender;

@CrossOrigin
@RestController
public class EmailCompaignController {

	//@Autowired
	RestTemplate restTemplate=new RestTemplate();
	
	@PostMapping(value = "/email-compaign")
	public ResponseEntity<String> createEmailCompaign(@RequestBody Email emailHtml) {
		ResponseEntity<String> responseEntity = null;
		System.out.println(emailHtml.html);
		try {
			Sender sender = new Sender();
			sender.setEmail("bytekarma012@gmail.com");
			sender.setName("byte karma");
			EmailCampaign emailCampaign = new EmailCampaign("electronics",sender,"AMAZON ELECTRONICS",emailHtml.html,"buy 1 get 1 free");
			emailCampaign.setnName("mohiit ghkbnln");
			HttpHeaders headers = new HttpHeaders();
			headers.set("api-key", "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");
			
			
			HttpEntity<EmailCampaign> request = new HttpEntity<>(emailCampaign,headers);
			ResponseEntity<Object> id = restTemplate.postForEntity("https://api.sendinblue.com/v3/emailCampaigns",request,Object.class);
			System.out.println();
			LinkedHashMap<String, Integer> res = (LinkedHashMap<String, Integer>)(id.getBody());
			
			System.out.println(res.get("id"));
		}catch (Exception e) {
//			e.printStackTrace();
//			System.out.println(e.getMessage());
			// TODO: handle exception
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,e.getMessage());
		}
		return responseEntity;
	}
	
	@PostMapping(value = "/email-compaign/send")
	public ResponseEntity<String> sendEmailCompaign() {
		ResponseEntity<String> responseEntity = null;
		
		try {
			Recepients recepients = new Recepients();
			List<String> emailList = new ArrayList<>();
			emailList.add("bytekarma012@gmail.com");
			emailList.add("aneeshbabu036@gmail.com");
			recepients.setEmailTo(emailList);
			HttpHeaders headers = new HttpHeaders();
			headers.set("api-key", "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");
			
			
			HttpEntity<Recepients> request = new HttpEntity<>(recepients,headers);
			ResponseEntity<Object> res = restTemplate.postForEntity("https://api.sendinblue.com/v3/emailCampaigns/"+17+"/sendTest",request,Object.class);
//			System.out.println(res);
			
			
			//System.out.println(res.get("id"));
		}catch (Exception e) {
//			e.printStackTrace();
//			System.out.println(e.getMessage());
			// TODO: handle exception
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,e.getMessage());
		}
		return responseEntity;
	}
	
	@GetMapping(value = "/email-compaign/get")
	public ResponseEntity<String> sendEmailgetMyCompaign(String senderId) {
		ResponseEntity<String> responseEntity = null;
		
		try {
			
			HttpHeaders headers = new HttpHeaders();
			headers.set("api-key", "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");
			
			
			HttpEntity request = new HttpEntity(headers);
		//	ResponseEntity<Object> res = restTemplate.getForEntity("https://api.sendinblue.com/v3/emailCampaigns",request,Object.class);
	//		System.out.println(res.getBody().getClass());
			return null;
			
			//System.out.println(res.get("id"));
		}catch (Exception e) {
//			e.printStackTrace();
//			System.out.println(e.getMessage());
			// TODO: handle exception
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,e.getMessage());
		}
		//return null;
	}
}
