package com.stripo.plugin.example.rest.dto;

import lombok.Data;

@Data
public class Email {
	private String html;
}
