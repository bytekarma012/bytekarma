package com.karma.model;


import com.karma.entity.SellerEntity;

public class Seller {

	private String sellerId,password,name;

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Seller [sellerId=" + sellerId + ", password=" + password + ", name=" + name + "]";
	}

	public static Seller entityToModel(SellerEntity sellerEntity) {
		Seller seller = new Seller();
		seller.setName(sellerEntity.getSellerId());
		seller.setSellerId(sellerEntity.getSellerId());
		seller.setPassword(sellerEntity.getPassword());
		return seller;
	}
	
	public static SellerEntity modelToEntity(Seller seller) {
		SellerEntity sellerEntity = new SellerEntity();
		sellerEntity.setName(seller.getName());
		sellerEntity.setPassword(seller.getPassword());
		sellerEntity.setSellerId(seller.getSellerId());
		return sellerEntity;
	}
}
