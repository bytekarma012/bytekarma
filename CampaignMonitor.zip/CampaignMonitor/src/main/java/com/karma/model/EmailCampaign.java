package com.karma.model;

public class EmailCampaign {

	private String tag;
	
	private Sender sender;
	
	private String name;
	
	private String htmlContent;
	
	private String subject;

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public Sender getSender() {
		return sender;
	}

	public void setSender(Sender sender) {
		this.sender = sender;
	}

	public String getName() {
		return name;
	}

	public void setnName(String name) {
		this.name = name;
	}

	public String getHtmlContent() {
		return htmlContent;
	}

	public void setHtmlContent(String htmlContent) {
		this.htmlContent = htmlContent;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public EmailCampaign(String tag, Sender sender, String name, String htmlContent, String subject) {
		super();
		this.tag = tag;
		this.sender = sender;
		this.name = name;
		this.htmlContent = htmlContent;
		this.subject = subject;
	}
	
	
}
