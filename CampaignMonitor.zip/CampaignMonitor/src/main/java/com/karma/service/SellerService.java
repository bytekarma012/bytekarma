package com.karma.service;

import com.karma.model.Seller;

public interface SellerService {

	public Boolean isValidSeller(String sellerId,String password);
	
	public void createSeller(Seller seller);
	
	public Seller getSellerDetails(String sellerId);
}
