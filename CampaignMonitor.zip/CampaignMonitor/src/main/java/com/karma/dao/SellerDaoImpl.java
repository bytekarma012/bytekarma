package com.karma.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import com.karma.entity.SellerEntity;
import com.karma.model.Seller;

@Repository(value = "sellerDao")
public class SellerDaoImpl implements SellerDao{

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public Boolean isValidSeller(String sellerId, String password) {
		// TODO Auto-generated method stub
		SellerEntity sellerEntity = entityManager.find(SellerEntity.class, sellerId);
		if(sellerEntity!=null) {
			if(sellerEntity.getPassword().equals(password))
				return true;
			return false;
		}
		return false;
	}

	@Override
	public void createSeller(Seller seller) {
		// TODO Auto-generated method stub
		SellerEntity sellerEntity = Seller.modelToEntity(seller);
		entityManager.persist(sellerEntity);
	}

	@Override
	public Seller getSellerDetails(String sellerId) {
		// TODO Auto-generated method stub
		SellerEntity sellerEntity = entityManager.find(SellerEntity.class, sellerId);
		Seller seller = Seller.entityToModel(sellerEntity);
		return seller;
	}

}
