package com.stripo.plugin.example.rest.dto;

import lombok.Data;

@Data
public class PluginToken {
	private String token;
}
