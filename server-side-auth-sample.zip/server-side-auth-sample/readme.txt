To start sample application:
- set pluginId and secretKey in ./bin/application.properties
- execute "java -jar ./bin/auth-service-0.1.jar" 