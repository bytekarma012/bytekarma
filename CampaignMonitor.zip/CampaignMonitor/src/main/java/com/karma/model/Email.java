package com.karma.model;
public class Email {
	public String html;
}
