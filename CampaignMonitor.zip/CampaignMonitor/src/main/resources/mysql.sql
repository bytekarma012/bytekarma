use compaign_monitor;

create table seller(
seller_id varchar(55) primary key,
name varchar(55),
password varchar(33)
);


INSERT INTO SELLER(SELLER_ID,NAME,PASSWORD) VALUES('35mohit@gmail.com','mohit','mohit');

select * from seller;